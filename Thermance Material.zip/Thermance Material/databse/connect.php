<?php
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$personnr = $_POST['personnr'];
	$nr = $_POST['nr'];

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(firstName, lastName, personnr, nr) values(?, ?, ?, ?)");
		$stmt->bind_param("ssii", $firstName, $lastName, $personnr, $nr);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>